# AI Agent Reference

This document is included in the published npm package so coding agents can
inspect the installed package in `node_modules` and use the API without needing
the source repository.

Package name:

```text
@jakkelab-aec/rw-dxf-engine-ts
```

## Package Boundary

- Root import: `@jakkelab-aec/rw-dxf-engine-ts`
- Three.js renderer import: `@jakkelab-aec/rw-dxf-engine-ts/renderer`
- AI-friendly Markdown API set: `docs/api-md/`
- Runtime `dependencies` are intentionally empty.
- The renderer subpath declares `three` as an optional peer dependency.
- Core APIs do not perform file IO, DOM downloads, Blob creation, or framework
  integration.
- Geometry inputs are plain structural objects such as `{ x, y, z }`.
- `dist/**/*.d.ts` contains the full generated type surface when more detail is
  needed.

## AI Markdown API Set

For ChatGPT Projects and coding agents, prefer the chunked Markdown reference
set under `docs/api-md/` before falling back to generated TypeDoc HTML. The
recommended ingestion order is documented in `docs/api-md/README.md`.

Use this single file for a compact package overview. Use `docs/api-md/` when a
tool benefits from topic-specific source files for writer, reader, blocks,
terrain, renderer, OSNAP, utility types, and limitations.

## Import Map

Root package:

```ts
import {
	DXFBlock,
	DXFBlockInsert,
	DXFCircle,
	DXFCylinder,
	DXFDrawUtils,
	DXFExtrusion,
	DXFLayer,
	DXFLine,
	DXFLineStyle,
	DXFLwPolyline,
	DXFMText,
	DXFPolyline,
	DXFReader,
	DXFText,
	DXFText3d,
	DXFTextStyle,
	DXFTriangle3d,
	DXFWriter,
	UnicodeConverter,
	transformDXFBlockPoint,
} from "@jakkelab-aec/rw-dxf-engine-ts";
```

Renderer subpath:

```ts
import {
	DXFImportedObject3D,
	DXFOsnapIndex,
	buildDXFBlockDefinitionSceneEntities,
	buildDXFSceneEntities,
	buildDXFOsnapCandidates,
	buildDXFOsnapSegments,
	computeDXFSceneBounds,
} from "@jakkelab-aec/rw-dxf-engine-ts/renderer";
```

## Core Types

Common point types:

```ts
type DxfPoint2D = { x: number; y: number };
type DxfPoint3D = { x: number; y: number; z: number };
type DxfLanguage = "ENG" | "KOR" | "JPN";
```

Writer entities implement:

```ts
interface IDXFWriterGeometryComponent {
	layer: DXFLayer;
	color: number;
	serialize(): string;
}
```

## Writer API

Primary class:

```ts
const writer = new DXFWriter({
	acadVersion: "AC1015",
	autoRegisterLayers: true,
	strictBlockReferences: true,
});
```

`DXFWriterOptions`:

- `acadVersion?: string`
  - DXF `$ACADVER` value.
  - When omitted, simple drawings use `AC1009`; entities requiring a newer
    version, such as `LWPOLYLINE` or `MTEXT`, resolve to `AC1015`.
- `autoRegisterLayers?: boolean`
  - Defaults to `true`.
  - Registers entity and block layers in the LAYER table automatically.
- `strictBlockReferences?: boolean`
  - Defaults to `true`.
  - Throws when an `INSERT` references a block that has not been registered.

`DXFWriter` methods:

- `registerLayer(layer: DXFLayer): void`
- `registerTextStyle(style: DXFTextStyle): void`
- `registerLineStyle(style: DXFLineStyle): void`
- `registerBlock(block: DXFBlock): void`
- `addBlock(block: DXFBlock): void`
- `addComponent(component: IDXFWriterGeometryComponent): void`
- `addComponents(components: IDXFWriterGeometryComponent[]): void`
- `getLayers(): DXFLayer[]`
- `getComponents(): IDXFWriterGeometryComponent[]`
- `getBlocks(): DXFBlock[]`
- `serialize(language?: DxfLanguage): string`
- `toString(): string`

Basic writer example:

```ts
const layer = new DXFLayer("GEOMETRY", 3);
const writer = new DXFWriter();

writer.addComponent(
	new DXFLine(
		{ x: 0, y: 0, z: 0 },
		{ x: 100, y: 0, z: 0 },
		layer,
	),
);
writer.addComponent(new DXFCircle(50, 50, 0, 25, layer));
writer.addComponent(new DXFText("A1", 10, 10, 0, 2.5, layer));

const dxfText = writer.serialize("ENG");
```

## Writer Styles

`DXFLayer(name, color = 7, lineStyle = "CONTINUOUS")`

```ts
const walls = new DXFLayer("WALLS", 3);
```

`DXFTextStyle(styleName, font, bigfont = "", height = 0, widthFactor = 1)`

```ts
const notes = new DXFTextStyle("NOTES", "arial.ttf");
```

`DXFLineStyle(styleName = "CONTINUOUS", description = "Solid line")`

```ts
const continuous = new DXFLineStyle();
```

## Writer Entities

`DXFLine(ptStart, ptEnd, layer, color = -1)`

```ts
writer.addComponent(
	new DXFLine(
		{ x: 0, y: 0, z: 0 },
		{ x: 100, y: 0, z: 0 },
		layer,
	),
);
```

`DXFCircle(x, y, z, r, layer, color = -1)`

```ts
writer.addComponent(new DXFCircle(50, 50, 0, 25, layer));
```

`DXFPolyline(pts, layer, color = -1)`

- Writes classic `POLYLINE` / `VERTEX` / `SEQEND`.
- Requires at least 2 points.

```ts
writer.addComponent(
	new DXFPolyline(
		[
			{ x: 0, y: 0, z: 0 },
			{ x: 10, y: 0, z: 0 },
		],
		layer,
	),
);
```

`DXFLwPolyline(vertices, layer, options = {})`

- Writes compact `LWPOLYLINE`.
- Requires at least 2 vertices.
- Supports `closed`, `elevation`, `thickness`, `constantWidth`, `extrusion`,
  per-vertex `startWidth`, `endWidth`, `bulge`, and `id`.
- Do not combine `constantWidth` with per-vertex widths.

```ts
writer.addComponent(
	new DXFLwPolyline(
		[
			{ x: 0, y: 0 },
			{ x: 100, y: 0, bulge: 0.25 },
			{ x: 100, y: 50 },
		],
		layer,
		{ closed: true, elevation: 2 },
	),
);
```

`DXFText(content, x, y, z, height, layer, color?, horizontalAlignment?, verticalAlignment?, style?)`

Alignment values:

- Horizontal: `"left"`, `"center"`, `"right"`, `"aligned"`, `"middle"`,
  `"fit"`
- Vertical: `"baseline"`, `"bottom"`, `"middle"`, `"top"`

```ts
writer.addComponent(
	new DXFText("Room A", 10, 20, 0, 2.5, layer, -1, "center", "middle", notes),
);
```

`DXFText3d(content, plane, coordinate, height, layer, color?, horizontalAlignment?, verticalAlignment?, style?)`

- `plane` is `"XY"`, `"YZ"`, or `"XZ"`.
- Writes TEXT with an extrusion direction for the selected plane.

```ts
writer.addComponent(
	new DXFText3d("Elevation", "XZ", { x: 0, y: 0, z: 10 }, 2, layer),
);
```

`DXFMText(content, position, height, layer, options = {})`

Options:

- `color?: number`
- `width?: number`
- `attachmentPoint?: "topLeft" | "topCenter" | "topRight" | "middleLeft" |
  "middleCenter" | "middleRight" | "bottomLeft" | "bottomCenter" |
  "bottomRight"`
- `drawingDirection?: "leftToRight" | "topToBottom" | "byStyle"`
- `style?: DXFTextStyle`
- `rotation?: number`
- `extrusion?: DxfPoint3D`
- `lineSpacingStyle?: "atLeast" | "exact"`
- `lineSpacingFactor?: number`

```ts
writer.addComponent(
	new DXFMText("Line one\\PLine two", { x: 0, y: 0, z: 0 }, 2.5, layer, {
		width: 120,
		attachmentPoint: "middleCenter",
		style: notes,
		lineSpacingStyle: "exact",
		lineSpacingFactor: 1.2,
	}),
);
```

`DXFBlock(name, basePoint = { x: 0, y: 0, z: 0 }, options = {})`

```ts
const block = new DXFBlock("DOOR_BLOCK");
block.addEntity(new DXFLine({ x: 0, y: 0, z: 0 }, { x: 90, y: 0, z: 0 }, layer));

writer.registerBlock(block);
```

`DXFBlockInsert(blockName, position, scale?, rotation = 0, layer?, color = -1)`

```ts
writer.addComponent(
	new DXFBlockInsert(
		"DOOR_BLOCK",
		{ x: 250, y: 100, z: 0 },
		{ x: 1, y: 1, z: 1 },
		0,
		layer,
	),
);
```

`DXFCylinder(center, radius, height, segmentsOrLayer, layerOrColor?, color?)`

- Serializes a cylinder approximation as multiple `3DFACE` records.
- Use `new DXFCylinder(center, radius, height, segments, layer, color?)` when
  controlling tessellation.
- Use `new DXFCylinder(center, radius, height, layer, color?)` for the default
  64 segments.

```ts
writer.addComponent(
	new DXFCylinder({ x: 0, y: 0, z: 0 }, 12, 40, 24, layer),
);
```

`DXFExtrusion(profile, basePoint, heightOrVector, layer, options = {})`

- Extrudes a closed 2D profile into capped `3DFACE` mesh output.
- `heightOrVector` may be a number or `{ x, y, z }`.
- Options: `color?: number`, `capStart?: boolean`, `capEnd?: boolean`.

```ts
writer.addComponent(
	new DXFExtrusion(
		[
			{ x: 0, y: 0 },
			{ x: 30, y: 0 },
			{ x: 30, y: 20 },
			{ x: 0, y: 20 },
		],
		{ x: 0, y: 0, z: 0 },
		40,
		layer,
	),
);
```

`DXFTriangle3d({ v1, v2, v3 }, layer, color = -1)`

```ts
writer.addComponent(
	new DXFTriangle3d(
		{
			v1: { x: 0, y: 0, z: 0 },
			v2: { x: 10, y: 0, z: 0 },
			v3: { x: 0, y: 10, z: 0 },
		},
		layer,
	),
);
```

## Reader API

Primary methods:

```ts
const parsed = DXFReader.parse(dxfText);
const validation = DXFReader.validate(dxfText);
const roundTrip = DXFReader.stringify(parsed);
const blockModel = DXFReader.getBlockModel(validation, { maxBlockDepth: 4 });
```

`DXFReader.parse(input: string): DXFParsedDocument`

- Parses raw DXF group-code pairs.
- Preserves every group in source order.
- Throws `DXFReadError` for malformed file structure.

`DXFParsedDocument`:

```ts
interface DXFParsedDocument {
	groups: DXFGroup[];
	sections: DXFSection[];
}

interface DXFGroup {
	code: number;
	value: string;
	line: number;
}

interface DXFSection {
	name: string;
	groups: DXFGroup[];
	startLine: number;
	endLine: number;
}
```

`DXFReader.validate(input: string, options?: DXFValidationOptions): DXFValidationResult`

- Does not throw for ordinary malformed DXF input.
- Returns line-level issues and higher-level summaries.
- Includes `document` when parsing succeeds.

`DXFValidationOptions`:

- `strictTextAlignmentPoint?: boolean`
  - Defaults to `false`.
  - Enable when TEXT entities must include complete `11` / `21` alignment
    point groups.
- `checkGroupValueTypes?: boolean`
  - Defaults to `true`.
  - Validates known group-code value types in the supported subset.

`DXFValidationResult`:

```ts
interface DXFValidationResult {
	ok: boolean;
	issues: DXFValidationIssue[];
	sections: DXFSectionSummary[];
	entities: DXFEntitySummary[];
	tables: DXFTableSummary[];
	blocks: DXFBlockSummary[];
	objects: DXFObjectSummary[];
	unknownRecords: DXFUnknownRecordSummary[];
	unknownRawRecords?: DXFUnknownRawRecords;
	document?: DXFParsedDocument;
}
```

`DXFValidationIssue` includes:

- `severity: "error" | "warning"`
- `message`
- `reason`
- `line`
- `content`
- optional `code`, `value`, `sectionName`, `entityType`
- optional stable `ruleId`
- optional `referencePaths`
- optional machine-readable `metadata`

Reader example:

```ts
const result = DXFReader.validate(dxfText);

if (!result.ok) {
	for (const issue of result.issues) {
		console.warn(issue.ruleId, issue.line, issue.reason);
	}
}

const lineSummary = result.entities.find((entity) => entity.type === "LINE");
```

Raw-preserving round trip:

```ts
const parsed = DXFReader.parse(dxfText);
const sameRawGroups = DXFReader.stringify(parsed);
```

## Block Model API

Use this when an app needs block definitions, resolved instances, nested INSERT
expansion, or block-local placement points mapped into drawing coordinates.

```ts
const blockModel = DXFReader.getBlockModel(dxfText, { maxBlockDepth: 4 });
const definition = blockModel.definitions.find((item) => item.name === "FOOTING_GRID");

if (definition) {
	const instances = blockModel.instances.filter((item) => item.blockName === definition.name);

	for (const instance of instances) {
		const drawingPoint = transformDXFBlockPoint({ x: 0, y: 0, z: 0 }, instance.transform);
		console.log(instance.path, drawingPoint);
	}
}
```

`DXFBlockModel`:

- `definitions: DXFBlockDefinition[]`
- `instances: DXFBlockInstance[]`
- `unresolvedInstances: DXFBlockInstance[]`

`DXFBlockDefinition` includes `name`, `layer`, `flags`, `basePoint`, raw child
`entities`, `entityCount`, `entityTypes`, source lines, `isExternalReference`,
and raw `groups`.

`DXFBlockInstance` includes `blockName`, optional `ownerBlockName`, `layer`,
`insertionPoint`, `scale`, `rotation`, `transform`, `depth`, `path`, source
lines, and raw `groups`. `transform` maps points from that instance's referenced
block-local coordinate system into drawing coordinates.

Unsupported data:

- Unknown sections, entities, table records, and object records remain
  inspectable through `unknownRecords` and `unknownRawRecords`.
- Do not discard unknown raw groups if the caller needs round-trip or
  diagnostics behavior.

## Renderer API

Install `three` in the consuming project:

```bash
npm install three
```

Create an imported object:

```ts
import * as THREE from "three";
import { DXFImportedObject3D } from "@jakkelab-aec/rw-dxf-engine-ts/renderer";

const scene = new THREE.Scene();
const imported = DXFImportedObject3D.fromDXFText(dxfText);

scene.add(imported);
```

`DXFImportedObject3D`:

- Extends `THREE.Object3D`.
- Constructor accepts `string | DXFParsedDocument | DXFValidationResult |
  DXFSceneEntity[] | undefined`.
- `entities: DXFSceneEntity[]`
- `selectableObjects: Map<string, THREE.Object3D>`
- `osnapIndex: DXFOsnapIndex`
- `static fromDXFText(input, options?)`
- `findOsnap(point, radius, options?)`
- `getObjectByEntityId(entityId)`
- `dispose()`

Constructor options:

```ts
interface DXFImportedObject3DOptions {
	name?: string;
	maxEntities?: number;
	maxPoints?: number;
	maxBlockDepth?: number;
}
```

Each selectable child receives:

```ts
object.userData.entityId;
object.userData.entity;
object.userData.baseColor;
```

Build scene entities without constructing Three.js objects:

```ts
const validation = DXFReader.validate(dxfText);
const entities = buildDXFSceneEntities(validation, {
	maxEntities: 50000,
	maxPoints: 500000,
	maxBlockDepth: 4,
});
```

Preview one block definition in block-local coordinates:

```ts
const blockEntities = buildDXFBlockDefinitionSceneEntities(dxfText, "FOOTING_GRID", {
	maxBlockDepth: 4,
});
```

The helper returns `DXFSceneEntity[]`, expands nested inserts inside the
definition up to `maxBlockDepth`, and attaches `sourceBlockName` plus
`sourceBlockBasePoint` metadata to returned entities.

`DXFSceneEntity`:

```ts
interface DXFSceneEntity {
	id: string;
	type: DXFSceneEntityType;
	layer: string;
	startLine: number;
	endLine: number;
	points: DXFScenePoint[];
	loops?: DXFScenePoint[][];
	radius?: number;
	startAngle?: number;
	endAngle?: number;
	closed?: boolean;
	filled?: boolean;
	text?: string;
	textHeight?: number;
	rotation?: number;
	blockName?: string;
	colorIndex?: number;
	trueColor?: number;
	sourceBlockName?: string;
	sourceBlockBasePoint?: DXFScenePoint;
}
```

Supported renderer entity types:

```ts
type DXFSceneEntityType =
	| "LINE"
	| "CIRCLE"
	| "ARC"
	| "TEXT"
	| "MTEXT"
	| "POLYLINE"
	| "LWPOLYLINE"
	| "SPLINE"
	| "INSERT"
	| "HATCH"
	| "3DFACE"
	| "POINT";
```

Renderer helpers:

- `createDXFEntityObject(entity): THREE.Object3D | null`
- `computeDXFSceneBounds(entities): { center, width, height }`
- `dxfEntityBaseColor(entity): number`
- `disposeDXFObject(object): void`
- `dxfColorIndexToRgb(index, fallback?): number`

Fit a camera around imported geometry:

```ts
const bounds = computeDXFSceneBounds(imported.entities);
const size = Math.max(bounds.width, bounds.height, 1);

camera.position.set(bounds.center.x, bounds.center.y, size);
camera.lookAt(bounds.center.x, bounds.center.y, 0);
```

Renderer limitations:

- Text is a lightweight preview, not a full CAD text layout engine.
- HATCH support is boundary/filled preview only, not complete AutoCAD hatch
  pattern generation.
- Spline display and curve snaps are approximate.
- OCS and arbitrary-axis transforms are not complete for every DXF entity.

## OSNAP API

Build an OSNAP index manually:

```ts
const candidates = buildDXFOsnapCandidates(entities);
const segments = buildDXFOsnapSegments(entities);
const osnap = new DXFOsnapIndex(candidates, segments);

const hit = osnap.findNearest({ x: 10, y: 20, z: 0 }, 5);
```

Snap kinds:

```ts
type DXFOsnapKind =
	| "endpoint"
	| "midpoint"
	| "center"
	| "quadrant"
	| "insertion"
	| "vertex"
	| "nearest"
	| "perpendicular"
	| "intersection";
```

Query with filters:

```ts
const hit = imported.findOsnap(pointerWorldPoint, worldRadius, {
	kinds: new Set(["endpoint", "midpoint", "center"]),
});
```

Perpendicular snaps require a reference point:

```ts
const hit = imported.findOsnap(pointerWorldPoint, worldRadius, {
	kinds: new Set(["perpendicular"]),
	referencePoint: previousPoint,
});
```

`DXFOsnapHit`:

```ts
interface DXFOsnapHit {
	id: string;
	entityId: string;
	entityType: DXFSceneEntityType;
	kind: DXFOsnapKind;
	point: DXFScenePoint;
	label: string;
	distance: number;
	sourceSegmentIds?: string[];
}
```

## Utility APIs

`DXFDrawUtils` namespace:

- `toPoint3D(point, defaultZ = 0)`
- `toPoint3DList(points, defaultZ = 0)`
- `createRectanglePolyline(minX, minY, maxX, maxY, z = 0)`
- `createCirclePolyline(x, y, z, radius, segments = 64)`
- `lineToDXFPoints({ p0, p1 })`
- `addNamedPolylines(writer, polylines, defaultZ = 0)`
- `serializePolylinesAsDXF({ polylines, language?, defaultZ? })`

Example:

```ts
const dxf = DXFDrawUtils.serializePolylinesAsDXF({
	language: "ENG",
	polylines: [
		{
			name: "RECTANGLE",
			color: 2,
			polyline: DXFDrawUtils.createRectanglePolyline(0, 0, 100, 50),
		},
	],
});
```

`UnicodeConverter`:

```ts
const escaped = UnicodeConverter.convertStringToUnicode("한글 TEXT");
```

- Converts Korean Hangul syllables to AutoCAD-style `\U+XXXX` escape
  sequences.
- Leaves non-Korean characters unchanged.

## Common Workflows

Write and validate:

```ts
const writer = new DXFWriter();
const layer = new DXFLayer("CHECK", 1);

writer.addComponent(new DXFLine({ x: 0, y: 0, z: 0 }, { x: 10, y: 0, z: 0 }, layer));

const dxfText = writer.serialize("ENG");
const validation = DXFReader.validate(dxfText);

if (!validation.ok) {
	throw new Error(validation.issues.map((issue) => issue.reason).join("\n"));
}
```

Parse, render, and snap:

```ts
const validation = DXFReader.validate(dxfText);
const imported = new DXFImportedObject3D(validation);

scene.add(imported);

const snap = imported.findOsnap({ x: 0, y: 0, z: 0 }, 10, {
	kinds: new Set(["endpoint", "center", "intersection"]),
});
```

Read unsupported records:

```ts
const result = DXFReader.validate(dxfText);

for (const unknown of result.unknownRecords) {
	console.log(unknown.kind, unknown.sectionName, unknown.type);
}

const rawUnknownEntities = result.unknownRawRecords?.entities ?? [];
```

## Package Contents

The published tarball is intended to include:

- `dist/**`
- `docs/AI_AGENT_REFERENCE.md`
- `docs/api-md/**`
- `README.md`
- `package.json`

Generated TypeDoc HTML is not currently included in the package tarball. Use the
included `.d.ts` files, this reference, and `docs/api-md/` when inspecting an
installed package.

## Release Commands For Maintainers

Verify package contents:

```powershell
cmd /c npm run release:dry
```

Publish to GitHub Packages:

```powershell
cmd /c npm run release:github
```

`release:github` bumps the patch version automatically before publishing. Use
`release:github:minor` or `release:github:major` for larger version changes.
