# Writer API

Use this file when creating DXF text with `DXFWriter` and writer entities.

## Main Class

```ts
import { DXFWriter } from "@jakkelab-aec/rw-dxf-engine-ts";

const writer = new DXFWriter({
	acadVersion: "AC1015",
	autoRegisterLayers: true,
	strictBlockReferences: true,
});
```

`DXFWriterOptions`:

- `acadVersion?: string`
  - DXF `$ACADVER` written to `HEADER`.
  - When omitted, simple drawings use `AC1009`.
  - Drawings with `LWPOLYLINE`, `MTEXT`, or `3DSOLID` use `AC1015`.
- `autoRegisterLayers?: boolean`
  - Defaults to `true`.
  - Registers entity and block layers in the LAYER table automatically.
- `strictBlockReferences?: boolean`
  - Defaults to `true`.
  - Throws during serialization if an `INSERT` references an unregistered
    block.

`DXFWriter` methods:

- `registerLayer(layer: DXFLayer): void`
- `registerTextStyle(style: DXFTextStyle): void`
- `registerLineStyle(style: DXFLineStyle): void`
- `registerBlock(block: DXFBlock): void`
- `addBlock(block: DXFBlock): void`
- `addComponent(component: IDXFWriterGeometryComponent): void`
- `addComponents(components: IDXFWriterGeometryComponent[]): void`
- `getLayers(): DXFLayer[]`
- `getComponents(): IDXFWriterGeometryComponent[]`
- `getBlocks(): DXFBlock[]`
- `serialize(language?: DxfLanguage): string`
- `toString(): string`

## Layers And Styles

```ts
const layer = new DXFLayer("GEOMETRY", 3);
const textStyle = new DXFTextStyle("NOTES", "arial.ttf");
const lineStyle = new DXFLineStyle("CONTINUOUS", "Solid line");
```

Classes:

- `DXFLayer(name, color = 7, lineStyle = "CONTINUOUS")`
- `DXFTextStyle(styleName, font, bigfont = "", height = 0, widthFactor = 1)`
- `DXFLineStyle(styleName = "CONTINUOUS", description = "Solid line")`
- `createDefaultLayer()`

Color convention:

- Entity `color = -1` means inherit the layer color in writer output.
- Layer color is an ACI color index.

## Writer Entity Contract

Writer entities implement:

```ts
interface IDXFWriterGeometryComponent {
	layer: DXFLayer;
	color: number;
	serialize(): string;
}
```

Add entities with:

```ts
writer.addComponent(entity);
writer.addComponents([entityA, entityB]);
```

## 2D Drawing Entities

`DXFLine(ptStart, ptEnd, layer, color = -1)`

```ts
writer.addComponent(
	new DXFLine({ x: 0, y: 0, z: 0 }, { x: 100, y: 0, z: 0 }, layer),
);
```

`DXFCircle(x, y, z, r, layer, color = -1)`

```ts
writer.addComponent(new DXFCircle(50, 50, 0, 25, layer));
```

`DXFPolyline(pts, layer, color = -1)`

- Writes classic `POLYLINE` / `VERTEX` / `SEQEND`.
- Requires at least 2 points.

```ts
writer.addComponent(
	new DXFPolyline(
		[
			{ x: 0, y: 0, z: 0 },
			{ x: 10, y: 0, z: 0 },
		],
		layer,
	),
);
```

`DXFLwPolyline(vertices, layer, options = {})`

- Writes compact `LWPOLYLINE`.
- Requires at least 2 vertices.
- Supports `closed`, `elevation`, `thickness`, `constantWidth`, `extrusion`,
  per-vertex `startWidth`, `endWidth`, `bulge`, and `id`.
- Do not combine `constantWidth` with per-vertex widths.

```ts
writer.addComponent(
	new DXFLwPolyline(
		[
			{ x: 0, y: 0 },
			{ x: 100, y: 0, bulge: 0.25 },
			{ x: 100, y: 50 },
		],
		layer,
		{ closed: true, elevation: 2 },
	),
);
```

## Text Entities

`DXFText(content, x, y, z, height, layer, color?, horizontalAlignment?, verticalAlignment?, style?)`

Horizontal alignment:

- `"left"`
- `"center"`
- `"right"`
- `"aligned"`
- `"middle"`
- `"fit"`

Vertical alignment:

- `"baseline"`
- `"bottom"`
- `"middle"`
- `"top"`

```ts
writer.addComponent(
	new DXFText("Room A", 10, 20, 0, 2.5, layer, -1, "center", "middle", textStyle),
);
```

`DXFText3d(content, plane, coordinate, height, layer, color?, horizontalAlignment?, verticalAlignment?, style?)`

- `plane` is `"XY"`, `"YZ"`, or `"XZ"`.
- Writes TEXT with extrusion direction for the selected plane.

```ts
writer.addComponent(
	new DXFText3d("Elevation", "XZ", { x: 0, y: 0, z: 10 }, 2, layer),
);
```

`DXFMText(content, position, height, layer, options = {})`

Options:

- `color?: number`
- `width?: number`
- `attachmentPoint?: "topLeft" | "topCenter" | "topRight" | "middleLeft" |
  "middleCenter" | "middleRight" | "bottomLeft" | "bottomCenter" |
  "bottomRight"`
- `drawingDirection?: "leftToRight" | "topToBottom" | "byStyle"`
- `style?: DXFTextStyle`
- `rotation?: number`
- `extrusion?: DxfPoint3D`
- `lineSpacingStyle?: "atLeast" | "exact"`
- `lineSpacingFactor?: number`

```ts
writer.addComponent(
	new DXFMText("Line one\\PLine two", { x: 0, y: 0, z: 0 }, 2.5, layer, {
		width: 120,
		attachmentPoint: "middleCenter",
		style: textStyle,
		lineSpacingStyle: "exact",
		lineSpacingFactor: 1.2,
	}),
);
```

## Blocks

`DXFBlock(name, basePoint = { x: 0, y: 0, z: 0 }, options = {})`

```ts
const block = new DXFBlock("DOOR_BLOCK");
block.addEntity(new DXFLine({ x: 0, y: 0, z: 0 }, { x: 90, y: 0, z: 0 }, layer));

writer.registerBlock(block);
```

`DXFBlockInsert(blockName, position, scale?, rotation = 0, layer?, color = -1)`

```ts
writer.addComponent(
	new DXFBlockInsert(
		"DOOR_BLOCK",
		{ x: 250, y: 100, z: 0 },
		{ x: 1, y: 1, z: 1 },
		0,
		layer,
	),
);
```

See `04-blocks-and-inserts.md` for block read and renderer behavior.

## 3D And Face Writers

`DXFCylinder(center, radius, height, segmentsOrLayer, layerOrColor?, color?)`

- Serializes a cylinder approximation as multiple `3DFACE` records.
- Use `new DXFCylinder(center, radius, height, segments, layer, color?)` when
  controlling tessellation.
- Use `new DXFCylinder(center, radius, height, layer, color?)` for the default
  64 segments.

```ts
writer.addComponent(new DXFCylinder({ x: 0, y: 0, z: 0 }, 12, 40, 24, layer));
```

`DXFExtrusion(profile, basePoint, heightOrVector, layer, options = {})`

- Extrudes a closed 2D profile into capped `3DFACE` mesh output.
- `heightOrVector` may be a number or `{ x, y, z }`.
- Options: `color?: number`, `capStart?: boolean`, `capEnd?: boolean`.

```ts
writer.addComponent(
	new DXFExtrusion(
		[
			{ x: 0, y: 0 },
			{ x: 30, y: 0 },
			{ x: 30, y: 20 },
			{ x: 0, y: 20 },
		],
		{ x: 0, y: 0, z: 0 },
		40,
		layer,
	),
);
```

`DXFTriangle3d({ v1, v2, v3 }, layer, color = -1)`

```ts
writer.addComponent(
	new DXFTriangle3d(
		{
			v1: { x: 0, y: 0, z: 0 },
			v2: { x: 10, y: 0, z: 0 },
			v3: { x: 0, y: 10, z: 0 },
		},
		layer,
	),
);
```

`DXF3DSolid(options = {})`

- Writes a `3DSOLID` entity.
- Can emit linked `ACDSDATA` with an `ASM_Data` record when `asmData` is
  provided.
- Preserves opaque modeler payloads.
- Does not generate ACIS/ASM B-Rep geometry from meshes or extrusions.

```ts
writer.addComponent(
	new DXF3DSolid({
		handle: "60",
		layer,
		modelerGeometryVersion: 1,
		asmData: {
			ownerHandle: "60",
			name: "ASM_Data",
			hexChunks,
		},
	}),
);
```

## Serialization Notes

`DXFWriter.serialize(language?: DxfLanguage)` accepts:

- `"ENG"`
- `"KOR"`
- `"JPN"`

Generated files include standard table records expected by common CAD loaders:

- `VPORT`
- `LTYPE`
- `LAYER`
- `STYLE`
- `VIEW`
- `UCS`
- `APPID`
- `DIMSTYLE`
- `BLOCK_RECORD` for non-`AC1009` block output

