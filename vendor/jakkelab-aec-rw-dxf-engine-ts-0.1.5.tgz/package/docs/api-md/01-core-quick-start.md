# Core Quick Start

Use this file for short examples that combine the main public APIs.

## Install

For GitHub Packages:

```text
@jakkelab-aec:registry=https://npm.pkg.github.com
```

```bash
npm install @jakkelab-aec/rw-dxf-engine-ts
```

For local development before publishing:

```powershell
cmd /c npm install E:\DEV\Projects\RWApps\rw-dxf-engine-ts
```

## Write A Simple DXF

```ts
import {
	DXFCircle,
	DXFLayer,
	DXFLine,
	DXFMText,
	DXFWriter,
} from "@jakkelab-aec/rw-dxf-engine-ts";

const layer = new DXFLayer("GEOMETRY", 3);
const writer = new DXFWriter();

writer.addComponent(new DXFLine({ x: 0, y: 0, z: 0 }, { x: 100, y: 0, z: 0 }, layer));
writer.addComponent(new DXFCircle(50, 50, 0, 25, layer));
writer.addComponent(new DXFMText("Room note\\PSecond line", { x: 10, y: 60, z: 0 }, 2.5, layer, { width: 80 }));

const dxfText = writer.serialize("ENG");
```

`serialize()` returns DXF text. Save that string using the file API supplied by
the host runtime.

## Read And Validate

```ts
import { DXFReader } from "@jakkelab-aec/rw-dxf-engine-ts";

const parsed = DXFReader.parse(dxfText);
const validation = DXFReader.validate(dxfText);

if (!validation.ok) {
	for (const issue of validation.issues) {
		console.warn(issue.ruleId, issue.line, issue.reason);
	}
}
```

Use `DXFReader.parse()` when malformed structure should throw `DXFReadError`.
Use `DXFReader.validate()` when a UI or import pipeline needs non-throwing
diagnostics.

## Raw-Preserving Round Trip

```ts
const parsed = DXFReader.parse(dxfText);
const roundTripText = DXFReader.stringify(parsed);
```

`stringify()` serializes the preserved raw group-code pairs back to DXF text.
It is intended for workflows that must keep unknown sections, entities, objects,
and group codes inspectable.

## Extract Terrain Meshes

```ts
const terrain = DXFReader.extractTerrainMesh(dxfText, { triangulate: true });

for (const face of terrain.faces) {
	const points = face.indices.map((index) => terrain.vertices[index]);
	console.log(points);
}
```

Supported terrain sources include:

- `3DFACE`
- modern `MESH`
- legacy polygon/polyface mesh `POLYLINE`

`3DSOLID` is preserved and counted, but not triangulated.

## Write And Use Blocks

```ts
import {
	DXFBlock,
	DXFBlockInsert,
	DXFLayer,
	DXFLine,
	DXFWriter,
} from "@jakkelab-aec/rw-dxf-engine-ts";

const layer = new DXFLayer("BLOCKS", 2);
const block = new DXFBlock("DOOR_BLOCK");
block.addEntity(new DXFLine({ x: 0, y: 0, z: 0 }, { x: 90, y: 0, z: 0 }, layer));

const writer = new DXFWriter();
writer.registerBlock(block);
writer.addComponent(new DXFBlockInsert("DOOR_BLOCK", { x: 250, y: 100, z: 0 }));

const dxfText = writer.serialize("ENG");
```

By default, `DXFWriter` throws if an `INSERT` references an unregistered block.

## Render With Three.js

Install `three` in the consuming project:

```bash
npm install three
```

```ts
import * as THREE from "three";
import { DXFImportedObject3D } from "@jakkelab-aec/rw-dxf-engine-ts/renderer";

const scene = new THREE.Scene();
const imported = DXFImportedObject3D.fromDXFText(dxfText);

scene.add(imported);

const snap = imported.findOsnap({ x: 0, y: 0, z: 0 }, 5);
```

The renderer import is intentionally separate from the root package.

