# Blocks And Inserts

Use this file for `DXFBlock`, `DXFBlockInsert`, BLOCKS summaries, INSERT
inspection, insertion points, and renderer expansion behavior.

## Write Block Definitions

```ts
import {
	DXFBlock,
	DXFBlockInsert,
	DXFLayer,
	DXFLine,
	DXFWriter,
} from "@jakkelab-aec/rw-dxf-engine-ts";

const layer = new DXFLayer("BLOCKS", 2);
const block = new DXFBlock("DOOR_BLOCK", { x: 0, y: 0, z: 0 });

block.addEntity(new DXFLine({ x: 0, y: 0, z: 0 }, { x: 90, y: 0, z: 0 }, layer));

const writer = new DXFWriter();
writer.registerBlock(block);
writer.addComponent(new DXFBlockInsert("DOOR_BLOCK", { x: 250, y: 100, z: 0 }));

const dxfText = writer.serialize("ENG");
```

`DXFBlock`:

- writes `BLOCK`
- writes nested entity DXF records
- writes `ENDBLK`
- has `name`, `basePoint`, `layer`, `flags`, and `entities`

`DXFBlockInsert`:

- writes `INSERT`
- group code `2`: block name
- group codes `10`, `20`, `30`: insertion point
- group codes `41`, `42`, `43`: scale
- group code `50`: rotation

## Writer Reference Rules

`DXFWriter` requires registered blocks by default:

```ts
const writer = new DXFWriter({ strictBlockReferences: true });
```

If an `INSERT` references an unregistered block, `serialize()` throws. Only set
`strictBlockReferences: false` when deliberately exporting unresolved block
inserts.

When blocks are registered:

- writer emits a `BLOCKS` section
- block-only drawings can stay on `AC1009`
- `BLOCK_RECORD` table entries are emitted for non-`AC1009` output

## Read Block Definitions

Use `DXFReader.validate(dxfText).blocks` for lightweight block definition
summaries:

```ts
const result = DXFReader.validate(dxfText);

for (const block of result.blocks) {
	console.log(block.name, block.basePoint, block.entityCount, block.entityTypes);
}
```

`DXFBlockSummary`:

```ts
interface DXFBlockSummary {
	name: string;
	layer: string;
	flags?: number;
	basePoint?: { x: number; y: number; z: number };
	entityCount: number;
	entityTypes: Record<string, number>;
	startLine: number;
	endLine: number;
	isExternalReference: boolean;
}
```

Use `DXFReader.getBlockModel()` when you need raw child entity records, resolved
INSERT instances, nested INSERTs, or block-local to drawing-coordinate
transforms:

```ts
import { DXFReader, transformDXFBlockPoint } from "@jakkelab-aec/rw-dxf-engine-ts";

const model = DXFReader.getBlockModel(dxfText, { maxBlockDepth: 4 });
const definition = model.definitions.find((item) => item.name === "FOOTING_GRID");

if (definition) {
	const instances = model.instances.filter((item) => item.blockName === definition.name);

	for (const instance of instances) {
		const drawingPoint = transformDXFBlockPoint(definition.basePoint, instance.transform);
		console.log(instance.path, drawingPoint);
	}
}
```

`DXFBlockModel`:

```ts
interface DXFBlockModel {
	definitions: DXFBlockDefinition[];
	instances: DXFBlockInstance[];
	unresolvedInstances: DXFBlockInstance[];
}
```

`DXFBlockDefinition`:

- `name`
- `layer`
- `flags`
- `basePoint`
- `entities`: raw child `DXFBlockEntityRecord[]` from the `BLOCKS` section
- `entityCount`
- `entityTypes`
- `startLine`
- `endLine`
- `isExternalReference`
- `groups`: raw `BLOCK` through `ENDBLK` group records

`DXFBlockInstance`:

- `blockName`
- optional `ownerBlockName` for nested INSERTs
- `layer`
- `insertionPoint`
- `scale`
- `rotation`
- `transform`: maps block-local coordinates to drawing coordinates
- `depth`
- `path`
- `resolved`
- `startLine`
- `endLine`
- `groups`

`DXFReader.getBlockModel()` accepts:

- `string`
- `DXFParsedDocument`
- `DXFValidationResult`

If a validation result has no parsed `document`, the method returns an empty
model.

## Find INSERT Instances By Block Name

Filter `DXFBlockModel.instances` by `blockName`:

```ts
const instances = DXFReader
	.getBlockModel(dxfText)
	.instances
	.filter((instance) => instance.blockName === "FOOTING_GRID");
```

## Insertion Point

For an `INSERT` entity:

- group code `10`: X insertion point
- group code `20`: Y insertion point
- group code `30`: Z insertion point

These are raw DXF coordinates. If the `INSERT` references a block with a nonzero
base point, `DXFBlockInstance.transform` already subtracts that base point
before applying scale and rotation.

## Inspect Internal Objects

Four levels are currently available:

1. Summary level:
   - `DXFReader.validate(dxfText).blocks`
   - tells you nested entity counts and entity types.
2. Block model level:
   - `DXFReader.getBlockModel(dxfText)`
   - exposes definitions, raw child entity records, resolved instances, nested
     instances, unresolved instances, and transforms.
3. Raw level:
   - `DXFReader.parse(dxfText).sections`
   - inspect the `BLOCKS` section directly between `BLOCK` and `ENDBLK`.
4. Renderer-expanded level:
   - `buildDXFSceneEntities(dxfText)`
   - returns transformed scene entities for inserted block geometry when the
     block definition is available.

## Renderer Block Expansion

```ts
import { buildDXFSceneEntities } from "@jakkelab-aec/rw-dxf-engine-ts/renderer";

const sceneEntities = buildDXFSceneEntities(dxfText, {
	maxBlockDepth: 4,
});
```

Renderer behavior for `INSERT`:

- finds the referenced block definition from the parsed `BLOCKS` section
- applies insertion point, scale, rotation, Z scale, and block base point
- expands child records into `DXFSceneEntity` objects
- follows nested block inserts up to `maxBlockDepth`
- resolves `BYBLOCK` color through the parent insert color when practical
- preserves nested `ATTRIB` records as text scene entities
- if expansion yields no children, returns an `INSERT` marker with
  `points[0]` and `blockName`

## Renderer Block Definition Preview

Use the renderer helper when a UI needs to preview one selected definition in
block-local coordinates before the user places anchors.

```ts
import { buildDXFBlockDefinitionSceneEntities } from "@jakkelab-aec/rw-dxf-engine-ts/renderer";

const definitionEntities = buildDXFBlockDefinitionSceneEntities(dxfText, "FOOTING_GRID", {
	maxBlockDepth: 4,
});
```

Returned entities include optional `sourceBlockName` and
`sourceBlockBasePoint` metadata. Direct definition entities keep raw block-local
coordinates. Nested INSERT children are expanded into the selected definition's
block-local coordinate system.

Renderer-expanded child `DXFSceneEntity` records are still preview geometry, not
a full CAD ownership graph. Use `DXFReader.getBlockModel()` for formal
definition and instance traversal.
