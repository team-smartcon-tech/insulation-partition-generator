# Reader API

Use this file when parsing, validating, summarizing, preserving, or inspecting
DXF input.

## Main Methods

```ts
import { DXFReader, transformDXFBlockPoint } from "@jakkelab-aec/rw-dxf-engine-ts";

const parsed = DXFReader.parse(dxfText);
const validation = DXFReader.validate(dxfText);
const roundTrip = DXFReader.stringify(parsed);
const terrainMesh = DXFReader.extractTerrainMesh(parsed);
const inventory = DXFReader.getEntityInventory(validation);
const blockModel = DXFReader.getBlockModel(validation, { maxBlockDepth: 4 });
```

## `DXFReader.parse(input)`

```ts
const parsed = DXFReader.parse(dxfText);
```

Returns `DXFParsedDocument` and may throw `DXFReadError` for malformed file
structure.

Important fields:

```ts
interface DXFParsedDocument {
	groups: DXFGroup[];
	sections: DXFSection[];
	entities: DXFParsedEntity[];
	acdsData?: DXFAcdsDataSection;
}

interface DXFGroup {
	code: number;
	value: string;
	line: number;
}

interface DXFSection {
	name: string;
	groups: DXFGroup[];
	startLine: number;
	endLine: number;
}
```

`groups` preserves every raw code/value pair in source order. `sections`
preserves named section contents. Higher-level `entities` currently exposes
additive structured `3DSOLID` records; most drawing entities remain inspectable
through raw groups and summaries.

## `DXFReader.validate(input, options)`

```ts
const result = DXFReader.validate(dxfText, {
	strictTextAlignmentPoint: false,
	checkGroupValueTypes: true,
});
```

`validate()` is intended for import pipelines and UI diagnostics. It should not
throw for ordinary malformed DXF input. It returns a failed result with
line-level issues when parsing or validation detects problems.

Options:

- `strictTextAlignmentPoint?: boolean`
  - Defaults to `false`.
  - Enable when `TEXT` entities must include complete `11` / `21` alignment
    point groups.
- `checkGroupValueTypes?: boolean`
  - Defaults to `true`.
  - Validates known group-code value types in the supported subset.

Result shape:

```ts
interface DXFValidationResult {
	ok: boolean;
	issues: DXFValidationIssue[];
	sections: DXFSectionSummary[];
	entities: DXFEntitySummary[];
	tables: DXFTableSummary[];
	blocks: DXFBlockSummary[];
	objects: DXFObjectSummary[];
	acdsData?: DXFAcdsDataSection;
	unknownRecords: DXFUnknownRecordSummary[];
	unknownRawRecords?: DXFUnknownRawRecords;
	document?: DXFParsedDocument;
}
```

## Validation Issues

`DXFValidationIssue` includes:

- `severity: "error" | "warning"`
- `message`
- `reason`
- `line`
- `content`
- optional `code`
- optional `value`
- optional `sectionName`
- optional `entityType`
- optional stable `ruleId`
- optional `referencePaths`
- optional machine-readable `metadata`

Example:

```ts
const result = DXFReader.validate(dxfText);

for (const issue of result.issues) {
	console.warn({
		severity: issue.severity,
		ruleId: issue.ruleId,
		line: issue.line,
		reason: issue.reason,
	});
}
```

## Summaries

`result.sections` summarizes top-level DXF sections.

`result.entities` summarizes `ENTITIES` records by entity type:

```ts
const insertSummary = result.entities.find((entity) => entity.type === "INSERT");
console.log(insertSummary?.count, insertSummary?.details?.blockNames);
```

`result.tables` summarizes tables and records such as:

- `LAYER`
- `LTYPE`
- `STYLE`
- `BLOCK_RECORD`

`result.blocks` summarizes `BLOCKS` definitions:

- `name`
- `layer`
- `flags`
- `basePoint`
- `entityCount`
- `entityTypes`
- `startLine`
- `endLine`
- `isExternalReference`

`result.objects` summarizes `OBJECTS` records.

## Block Model Method

`DXFReader.getBlockModel(input, options?)`

Input may be:

- `string`
- `DXFParsedDocument`
- `DXFValidationResult`

Options:

- `maxBlockDepth?: number`
  - Defaults to `4`.
  - Controls nested INSERT expansion.

Result shape:

```ts
interface DXFBlockModel {
	definitions: DXFBlockDefinition[];
	instances: DXFBlockInstance[];
	unresolvedInstances: DXFBlockInstance[];
}
```

Use `transformDXFBlockPoint(point, instance.transform)` to convert a
block-local point to drawing coordinates.

```ts
const model = DXFReader.getBlockModel(dxfText);
const definition = model.definitions.find((item) => item.name === "FOOTING_GRID");

if (definition) {
	for (const instance of model.instances.filter((item) => item.blockName === definition.name)) {
		const drawingPoint = transformDXFBlockPoint(definition.basePoint, instance.transform);
		console.log(drawingPoint);
	}
}
```

See `04-blocks-and-inserts.md` for the block definition and instance field
contracts.

## Unknown And Raw Records

Unknown but structurally readable data is preserved. Use:

```ts
const result = DXFReader.validate(dxfText);

for (const unknown of result.unknownRecords) {
	console.log(unknown.kind, unknown.sectionName, unknown.type);
}

const rawUnknownEntities = result.unknownRawRecords?.entities ?? [];
```

Unknown raw record categories:

- `unknownRawRecords.sections`
- `unknownRawRecords.entities`
- `unknownRawRecords.tableRecords`
- `unknownRawRecords.objects`

Raw records may include a `context` object with parent section/table, handle,
owner handle, hard-owner handle, and block-record handle metadata derived from
preserved group codes.

## Raw-Preserving Stringify

```ts
const parsed = DXFReader.parse(dxfText);
const preserved = DXFReader.stringify(parsed);
```

Use `DXFReader.stringify(parsedDocument)` when the caller wants to keep unknown
sections, entities, objects, and group codes. It normalizes line endings to
`\n`.

## Terrain Methods

`DXFReader.extractTerrainMesh(input, options?)`

Input may be:

- `string`
- `DXFParsedDocument`
- `DXFValidationResult`

Options:

- `triangulate?: boolean`
  - `false` by default.
  - When `true`, emits triangles only.

`DXFReader.getEntityInventory(input)` returns counts and support hints without
extracting geometry.

See `05-terrain-3d-and-binary.md` for details.

## Error Class

`DXFReadError` extends `Error` and includes:

- `line`
- `content`
- `code`
- `value`
- `reason`
- `ruleId`
- `referencePaths`

Use `validate()` instead of `parse()` if the host should receive structured
diagnostics instead of exceptions.
