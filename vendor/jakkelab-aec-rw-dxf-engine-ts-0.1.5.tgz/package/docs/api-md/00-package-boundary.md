# Package Boundary

Package: `@jakkelab-aec/rw-dxf-engine-ts`

Use this file when deciding which APIs to import, what the package is allowed
to do, and what responsibilities belong to the host application.

## Purpose

`rw-dxf-engine-ts` provides TypeScript DXF read/write primitives:

- write DXF text from simple structural objects
- read DXF text into raw group-code data and summaries
- validate file structure and supported entity/table/block subsets
- extract terrain-ready mesh data from supported face/mesh entities
- optionally build Three.js preview objects through a renderer subpath

The package is intended to stay small, portable, and runtime-dependency-free at
the root import.

## Root Import

Use the root import for parser, writer, terrain, binary, and utility APIs:

```ts
import {
	DXFReader,
	DXFWriter,
	DXFLayer,
	DXFLine,
	DXFBlock,
	DXFBlockInsert,
} from "@jakkelab-aec/rw-dxf-engine-ts";
```

The root package exports core classes such as:

- `DXFWriter`
- `DXFReader`
- `DXFLayer`, `DXFTextStyle`, `DXFLineStyle`
- `DXFLine`, `DXFCircle`, `DXFPolyline`, `DXFLwPolyline`
- `DXFText`, `DXFText3d`, `DXFMText`
- `DXFBlock`, `DXFBlockInsert`
- `DXFCylinder`, `DXFExtrusion`, `DXFTriangle3d`, `DXF3DSolid`
- `DXFDrawUtils`
- `UnicodeConverter`
- `bytesToDxfHexChunks`, `dxfHexChunksToBytes`, `normalizeDxfHexChunks`

## Renderer Import

Use the renderer subpath only when a project wants Three.js objects, scene
entities, text geometry, colors, or OSNAP helpers:

```ts
import {
	DXFImportedObject3D,
	buildDXFSceneEntities,
	DXFOsnapIndex,
} from "@jakkelab-aec/rw-dxf-engine-ts/renderer";
```

The renderer subpath exports:

- `DXFImportedObject3D`
- `buildDXFSceneEntities`
- `createDXFEntityObject`
- `computeDXFSceneBounds`
- `DXFOsnapIndex`
- `buildDXFOsnapCandidates`
- `buildDXFOsnapSegments`
- `dxfColorIndexToRgb`
- `dxfEntityBaseColor`
- `DEFAULT_DXF_TEXT_FONT_DATA`
- `getDXFTextFont`

## Dependency Policy

Root package runtime dependencies are intentionally empty:

```json
"dependencies": {}
```

`three` is an optional peer dependency for the renderer subpath. A consuming
project must install `three` when using `@jakkelab-aec/rw-dxf-engine-ts/renderer`.

## Host Application Responsibilities

The core package does not:

- write files to disk
- read files from disk
- create DOM downloads
- create `Blob`, `File`, or `URL` objects
- depend on React, Vite, Three.js, or a CAD runtime from the root import
- resolve external references or xrefs
- generate ACIS/ASM B-Rep geometry from arbitrary meshes

The host application should provide file IO, upload/download behavior, UI,
framework integration, and persistence.

## Data Shape Rules

Public runtime APIs prefer plain structural data:

```ts
type DxfPoint2D = { x: number; y: number };
type DxfPoint3D = { x: number; y: number; z: number };
```

DXF output is returned as a string:

```ts
const dxfText = writer.serialize("ENG");
```

DXF input is accepted as a string for reader and renderer entry points:

```ts
const parsed = DXFReader.parse(dxfText);
const validation = DXFReader.validate(dxfText);
```

