# Terrain, 3D, And Binary Helpers

Use this file for terrain extraction, 3D support, `3DSOLID`, `ACDSDATA`, and DXF
hex chunk helpers.

## Terrain Mesh Extraction

```ts
import { DXFReader } from "@jakkelab-aec/rw-dxf-engine-ts";

const terrain = DXFReader.extractTerrainMesh(dxfText, {
	triangulate: true,
});
```

Input may be:

- `string`
- `DXFParsedDocument`
- `DXFValidationResult`

Options:

```ts
interface DXFTerrainMeshOptions {
	triangulate?: boolean;
}
```

When `triangulate` is false or omitted, quads are preserved. When it is true,
the API emits triangles only.

## Terrain Result

```ts
interface DXFTerrainMesh {
	vertices: DXFTerrainMeshVertex[];
	faces: DXFTerrainMeshFace[];
	stats: DXFTerrainMeshStats;
	warnings: DXFDiagnostic[];
}

interface DXFTerrainMeshVertex {
	x: number;
	y: number;
	z: number;
}

interface DXFTerrainMeshFace {
	indices: [number, number, number] | [number, number, number, number];
}
```

Each face references indices in `terrain.vertices`.

## Supported Terrain Sources

The terrain extractor decodes:

- `3DFACE`
- modern `MESH`
- legacy polyface mesh `POLYLINE`
- legacy polygon mesh `POLYLINE`

Malformed individual terrain faces are reported in `terrain.warnings` instead
of aborting the entire extraction.

## Terrain Stats

```ts
interface DXFTerrainMeshStats {
	face3dCount: number;
	meshCount: number;
	polyfaceMeshCount: number;
	polygonMeshCount: number;
	solid3dCount: number;
	ignoredEntityCounts: Record<string, number>;
	unsupportedEntityTypes: string[];
}
```

Use stats for import messages:

```ts
const terrain = DXFReader.extractTerrainMesh(dxfText);

if (terrain.stats.unsupportedEntityTypes.includes("3DSOLID")) {
	console.warn("3DSOLID modeler geometry was preserved but not triangulated.");
}
```

## Entity Inventory

Use `DXFReader.getEntityInventory()` when a host app wants a preflight summary
without extracting geometry:

```ts
const inventory = DXFReader.getEntityInventory(dxfText);

console.log(inventory.totalEntities);
console.log(inventory.meshBearingEntityCounts);
console.log(inventory.unsupportedEntityTypes);
```

`DXFEntityInventory`:

- `totalEntities`
- `entityCounts`
- `meshBearingEntityCounts`
- `ignoredEntityCounts`
- `unsupportedEntityTypes`

## 3DSOLID Read Behavior

`3DSOLID` is treated as opaque modeler geometry.

Reader behavior:

- parses raw `3DSOLID` groups
- exposes structured `DXFParsed3DSolid` records through
  `DXFParsedDocument.entities`
- links `3DSOLID` handles to `ACDSDATA` records named `ASM_Data` when possible
- preserves proprietary group code `1` and `3` data
- does not triangulate ACIS/ASM payloads

Terrain extraction behavior:

- counts `3DSOLID`
- adds `"3DSOLID"` to `unsupportedEntityTypes`
- emits warning rule `DXF-TERRAIN-3DSOLID-UNSUPPORTED`

## 3DSOLID Write Behavior

Use `DXF3DSolid` when the caller already has a valid ASM/ACIS payload or wants
to preserve modeler payload data:

```ts
import {
	bytesToDxfHexChunks,
	DXF3DSolid,
	DXFLayer,
	DXFWriter,
} from "@jakkelab-aec/rw-dxf-engine-ts";

const layer = new DXFLayer("SOLID", 7);
const asmBytes = new Uint8Array([/* existing ASM/ACIS payload bytes */]);
const hexChunks = bytesToDxfHexChunks(asmBytes);

const writer = new DXFWriter({ acadVersion: "AC1027" });

writer.addComponent(
	new DXF3DSolid({
		handle: "60",
		layer,
		modelerGeometryVersion: 1,
		asmData: {
			ownerHandle: "60",
			name: "ASM_Data",
			hexChunks,
		},
	}),
);
```

`DXF3DSolid` does not generate ACIS/ASM B-Rep geometry from arbitrary mesh,
polyline, or extrusion inputs.

## Binary And Hex Helpers

The root package exports:

- `bytesToDxfHexChunks(bytes, chunkSize?)`
- `dxfHexChunksToBytes(chunks)`
- `normalizeDxfHexChunks(chunks)`

Typical flow:

```ts
const bytes = new Uint8Array([0x01, 0x02, 0xff]);
const chunks = bytesToDxfHexChunks(bytes);
const decoded = dxfHexChunksToBytes(chunks);
```

Use these helpers for DXF group code `310` binary hex payloads, especially
`ACDSDATA` / `ASM_Data` preservation.

## 3D Writer Helpers

The writer also includes 3D-ish face generation helpers:

- `DXFTriangle3d`
- `DXFCylinder`
- `DXFExtrusion`

These generate `3DFACE`-based geometry, not solid-modeling ACIS bodies.

