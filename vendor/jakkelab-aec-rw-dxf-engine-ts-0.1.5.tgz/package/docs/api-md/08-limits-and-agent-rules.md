# Limits And Agent Rules

Use this file before making claims about full DXF support or changing package
behavior.

## Supported Scope

The library currently supports practical read/write and preview workflows for a
subset of DXF:

- writer output for common 2D entities
- writer output for blocks and inserts
- writer output for 3DFACE-based 3D helpers
- opaque `3DSOLID` payload preservation and writing
- parser raw group and section preservation
- validation summaries for sections, entities, tables, blocks, and objects
- terrain extraction from `3DFACE`, `MESH`, and mesh-form `POLYLINE`
- optional Three.js renderer and OSNAP helpers

Do not claim full AutoCAD 2024 DXF coverage.

## Known Limitations

Reader:

- Most entity data remains raw group data plus summaries.
- `DXFParsedDocument.entities` is additive and currently focused on structured
  `3DSOLID` records.
- There is no complete high-level CAD database or ownership graph.
- `DXFReader.getBlockModel()` provides block definitions and effective INSERT
  instances, but it is not a complete CAD ownership database.

Writer:

- `DXF3DSolid` preserves or writes opaque modeler payload metadata, but does not
  generate ACIS/ASM B-Rep bodies.
- `DXFCylinder`, `DXFExtrusion`, and `DXFTriangle3d` write `3DFACE` geometry,
  not true solids.
- Runtime `dependencies` must stay empty unless the dependency policy changes.

Renderer:

- Text rendering is preview-quality.
- HATCH rendering is lightweight.
- Spline display is approximate.
- OCS and arbitrary-axis transforms are not complete for every entity.
- Expanded block child scene entities should not be treated as a stable public
  block-instance graph.

Terrain:

- `3DSOLID` is counted and warned as unsupported for triangulation.
- Malformed individual terrain faces produce warnings instead of aborting the
  whole extraction.

## Agent Rules For API Answers

When answering usage questions:

- Prefer root imports for parser/writer/utility APIs.
- Use renderer subpath imports for Three.js, scene entities, and OSNAP.
- Mention that `three` is optional and must be installed by renderer consumers.
- Say that file IO and browser downloads belong to the host app.
- Say that raw groups are preserved and are the escape hatch for unsupported
  DXF records.
- Prefer `DXFReader.validate()` for non-throwing import diagnostics.
- Prefer `DXFReader.parse()` when the caller wants thrown `DXFReadError`.
- Prefer `DXFReader.extractTerrainMesh()` over low-level terrain helpers for
  ordinary consumers.
- Prefer `DXFReader.getBlockModel()` and `transformDXFBlockPoint()` when a host
  app needs block definitions, resolved INSERT instances, or block-local
  placement points mapped into drawing coordinates.

## Agent Rules For Code Changes

Before changing public APIs or DXF group-code behavior, read:

- `AGENTS.md`
- `.agents/API_CONTRACT.md`
- `.agents/DXF_IMPLEMENTATION_ROADMAP.md`
- `.agents/DXF_FILE_FORMAT_VALIDATION_PLAN.md` for parser validation changes
- `.agents/DXF_REFERENCE_GUIDE.md`
- relevant AutoCAD 2024 reference files under `.agents/references/`

Keep changes additive when possible:

- preserve raw groups
- keep existing constructor signatures compatible
- export new root public APIs from `src/index.ts`
- export renderer APIs from `src/renderer.ts`
- update TSDoc for public classes, functions, and types
- update `.agents/API_CONTRACT.md` when public behavior changes
- update README when install, build, or basic usage changes

## Verification Commands

Choose checks based on risk:

```powershell
cmd /c npm run build
cmd /c npm test
cmd /c npm run docs
cmd /c npm run typecheck:tester
cmd /c npm run build:tester
cmd /c npm pack --dry-run
```

For documentation-only changes, at least search for stale terms and verify that
Markdown references point at real files.

## Generated Docs

TypeDoc output:

- `docs/api/`
- `docs/api.json`

AI Markdown companion:

- `docs/api-md/`

If public API signatures change, regenerate TypeDoc and update this Markdown
set so examples and signatures stay aligned.
