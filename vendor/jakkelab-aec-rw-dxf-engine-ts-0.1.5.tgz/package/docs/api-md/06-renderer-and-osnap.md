# Renderer And OSNAP

Use this file for Three.js preview objects, scene entities, text geometry,
colors, bounds, and object snaps.

## Import

Install `three` in the consuming project:

```bash
npm install three
```

Import renderer APIs from the subpath:

```ts
import {
	DXFImportedObject3D,
	buildDXFBlockDefinitionSceneEntities,
	buildDXFSceneEntities,
	computeDXFSceneBounds,
	DXFOsnapIndex,
} from "@jakkelab-aec/rw-dxf-engine-ts/renderer";
```

Do not import renderer APIs from the root package.

## DXFImportedObject3D

```ts
import * as THREE from "three";
import { DXFImportedObject3D } from "@jakkelab-aec/rw-dxf-engine-ts/renderer";

const scene = new THREE.Scene();
const imported = DXFImportedObject3D.fromDXFText(dxfText);

scene.add(imported);
```

`DXFImportedObject3D`:

- extends `THREE.Object3D`
- owns selectable child objects
- stores scene entities in `entities`
- stores child objects in `selectableObjects`
- builds an `osnapIndex`

Constructor input:

```ts
type DXFSceneSource =
	| string
	| DXFParsedDocument
	| DXFValidationResult
	| DXFSceneEntity[]
	| undefined;
```

Constructor options:

- `name?: string`
- `maxEntities?: number`
- `maxPoints?: number`
- `maxBlockDepth?: number`
- `textGeometry?: DXFTextGeometryOptions`

Methods:

- `static fromDXFText(input, options?)`
- `findOsnap(point, radius, options?)`
- `getObjectByEntityId(entityId)`
- `dispose()`

Each selectable child receives:

```ts
object.userData.entityId;
object.userData.entity;
object.userData.baseColor;
```

## Scene Entities Without Three.js Objects

```ts
const entities = buildDXFSceneEntities(dxfText, {
	maxEntities: 50000,
	maxPoints: 500000,
	maxBlockDepth: 4,
});
```

`DXFSceneEntity`:

```ts
interface DXFSceneEntity {
	id: string;
	type: DXFSceneEntityType;
	layer: string;
	startLine: number;
	endLine: number;
	points: DXFScenePoint[];
	loops?: DXFScenePoint[][];
	radius?: number;
	startAngle?: number;
	endAngle?: number;
	closed?: boolean;
	filled?: boolean;
	text?: string;
	textHeight?: number;
	rotation?: number;
	blockName?: string;
	colorIndex?: number;
	trueColor?: number;
	sourceBlockName?: string;
	sourceBlockBasePoint?: DXFScenePoint;
}
```

Supported scene entity types:

- `LINE`
- `CIRCLE`
- `ARC`
- `TEXT`
- `MTEXT`
- `POLYLINE`
- `LWPOLYLINE`
- `SPLINE`
- `INSERT`
- `HATCH`
- `3DFACE`
- `POINT`

## Blocks In The Renderer

`buildDXFSceneEntities()` expands block inserts when the referenced block
definition is present. It applies:

- insertion point
- scale
- rotation
- Z scale
- block base point
- nested block expansion up to `maxBlockDepth`

If a block cannot be expanded or has no drawable children, the renderer returns
an `INSERT` marker with `points[0]` and `blockName`.

Use `buildDXFBlockDefinitionSceneEntities(source, blockName, options?)` to
preview one selected definition without model-space INSERT placement:

```ts
const blockEntities = buildDXFBlockDefinitionSceneEntities(dxfText, "FOOTING_GRID", {
	maxBlockDepth: 4,
});
```

The returned `DXFSceneEntity[]` uses the selected definition's block-local
coordinates. Direct child objects are not shifted by the definition base point.
Nested INSERT children are expanded inside that same block-local coordinate
system. Each returned entity includes optional `sourceBlockName` and
`sourceBlockBasePoint` metadata so modal viewports can keep the preview tied to
the selected definition.

## Create One Object

```ts
const object = createDXFEntityObject(entity, {
	textGeometry: {
		fontData: DEFAULT_DXF_TEXT_FONT_DATA,
		depth: 0.01,
		curveSegments: 4,
	},
});
```

`createDXFEntityObject(entity, options?)` returns `THREE.Object3D | null`.

## Text Font Helpers

Exports:

- `DEFAULT_DXF_TEXT_FONT_DATA`
- `getDXFTextFont(fontData?)`

The default font JSON is published at:

```text
@jakkelab-aec/rw-dxf-engine-ts/renderer/fonts/font_default.json
```

Text rendering is a lightweight preview. It is not a complete CAD text layout
engine.

## Bounds And Colors

```ts
const bounds = computeDXFSceneBounds(imported.entities);
const size = Math.max(bounds.width, bounds.height, 1);

camera.position.set(bounds.center.x, bounds.center.y, size);
camera.lookAt(bounds.center.x, bounds.center.y, 0);
```

Color helpers:

- `dxfColorIndexToRgb(index, fallback?)`
- `dxfEntityBaseColor(entity)`

## OSNAP

Build an OSNAP index manually:

```ts
const candidates = buildDXFOsnapCandidates(entities);
const segments = buildDXFOsnapSegments(entities);
const osnap = new DXFOsnapIndex(candidates, segments);

const hit = osnap.findNearest({ x: 10, y: 20, z: 0 }, 5);
```

Or use the imported object:

```ts
const hit = imported.findOsnap(pointerWorldPoint, worldRadius, {
	kinds: new Set(["endpoint", "midpoint", "center"]),
});
```

Snap kinds:

- `endpoint`
- `midpoint`
- `center`
- `quadrant`
- `insertion`
- `vertex`
- `nearest`
- `perpendicular`
- `intersection`

Perpendicular snaps require a reference point:

```ts
const hit = imported.findOsnap(pointerWorldPoint, worldRadius, {
	kinds: new Set(["perpendicular"]),
	referencePoint: previousPoint,
});
```

`DXFOsnapHit`:

```ts
interface DXFOsnapHit {
	id: string;
	entityId: string;
	entityType: DXFSceneEntityType;
	kind: DXFOsnapKind;
	point: DXFScenePoint;
	label: string;
	distance: number;
	sourceSegmentIds?: string[];
}
```

## Renderer Limitations

- Text is preview-quality, not full CAD text layout.
- HATCH is boundary/filled preview, not complete AutoCAD hatch pattern output.
- Spline display and curve snaps are approximate.
- OCS and arbitrary-axis transforms are not complete for every DXF entity.
- Parent block-instance graph objects are not a stable public renderer API; use
  `DXFReader.getBlockModel()` for definition and instance traversal.
