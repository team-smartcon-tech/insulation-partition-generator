# Utilities And Common Types

Use this file for structural types, `DXFDrawUtils`, `UnicodeConverter`, and
small helper APIs.

## Structural Geometry Types

Common root package types:

```ts
interface DxfPoint2D {
	x: number;
	y: number;
}

interface DxfPoint3D {
	x: number;
	y: number;
	z: number;
}
```

Renderer point type:

```ts
interface DXFScenePoint {
	x: number;
	y: number;
	z: number;
}
```

Terrain point type:

```ts
interface DXFTerrainMeshVertex {
	x: number;
	y: number;
	z: number;
}
```

These are structural plain objects. Do not require geometry classes from other
packages.

## DXFDrawUtils

Import from the root package:

```ts
import { DXFDrawUtils } from "@jakkelab-aec/rw-dxf-engine-ts";
```

Functions:

- `toPoint3D(point, defaultZ = 0)`
- `toPoint3DList(points, defaultZ = 0)`
- `createRectanglePolyline(minX, minY, maxX, maxY, z = 0)`
- `createCirclePolyline(x, y, z, radius, segments = 64)`
- `lineToDXFPoints({ p0, p1 })`
- `addNamedPolylines(writer, polylines, defaultZ = 0)`
- `serializePolylinesAsDXF({ polylines, language?, defaultZ? })`

Example:

```ts
const dxf = DXFDrawUtils.serializePolylinesAsDXF({
	language: "ENG",
	polylines: [
		{
			name: "RECTANGLE",
			color: 2,
			polyline: DXFDrawUtils.createRectanglePolyline(0, 0, 100, 50),
		},
	],
});
```

`DXFDrawUtils` is useful when callers have simple polylines and want a quick DXF
string without manually constructing a `DXFWriter`.

## UnicodeConverter

```ts
import { UnicodeConverter } from "@jakkelab-aec/rw-dxf-engine-ts";

const escaped = UnicodeConverter.convertStringToUnicode("Korean text");
```

`UnicodeConverter.convertStringToUnicode()` converts Korean Hangul syllables to
AutoCAD-style `\U+XXXX` escape sequences and leaves other characters unchanged.

## Language Type

`DxfLanguage` is used by `DXFWriter.serialize(language)`:

```ts
type DxfLanguage = "ENG" | "KOR" | "JPN";
```

Example:

```ts
const dxfText = writer.serialize("KOR");
```

## Validation Types

Useful public reader types:

- `DXFValidationResult`
- `DXFValidationIssue`
- `DXFValidationOptions`
- `DXFSectionSummary`
- `DXFEntitySummary`
- `DXFTableSummary`
- `DXFBlockSummary`
- `DXFObjectSummary`
- `DXFUnknownRecordSummary`
- `DXFUnknownRawRecords`

Use `DXFValidationIssue.ruleId` for stable issue matching in host UIs and test
fixtures.

## Raw Group Types

```ts
interface DXFGroup {
	code: number;
	value: string;
	line: number;
}

type DXFRawGroup = DXFGroup;
```

Raw groups are the safest escape hatch for unsupported DXF data. Preserve them
when building higher-level workflows.

## Writer Types

Useful writer types:

- `DxfSerializable`
- `IDXFWriterGeometryComponent`
- `DXFWriterOptions`
- `DXFLwPolylineVertex`
- `DXFLwPolylineOptions`
- `DXFMTextOptions`
- `DXFBlockOptions`
- `DXFExtrusionOptions`
- `DXF3DSolidOptions`
- `DXFTriangleVertices`

## Renderer Types

Useful renderer types:

- `DXFSceneEntity`
- `DXFSceneEntityType`
- `DXFScenePoint`
- `DXFSceneSource`
- `BuildDXFSceneEntitiesOptions`
- `DXFImportedObject3DOptions`
- `DXFEntityObjectOptions`
- `DXFTextGeometryOptions`
- `DXFOsnapKind`
- `DXFOsnapCandidate`
- `DXFOsnapSegment`
- `DXFOsnapHit`
- `DXFOsnapQueryOptions`
- `DXFSceneBounds`

Renderer types should be imported from:

```ts
import type { DXFSceneEntity } from "@jakkelab-aec/rw-dxf-engine-ts/renderer";
```

## Low-Level Terrain Helpers

The root package also exports low-level helpers:

- `createEmptyTerrainMesh`
- `extractTerrainMeshFromEntityRecords`
- `buildDXFEntityInventory`

Most consumers should prefer the higher-level `DXFReader.extractTerrainMesh()`
and `DXFReader.getEntityInventory()` methods.

