# AI Markdown API Reference

Package: `@jakkelab-aec/rw-dxf-engine-ts`
Version documented: `0.1.4`
Source of truth: `docs/api.json`, `docs/api/`, `src/index.ts`, and
`src/renderer.ts`.

This folder is a Markdown companion to the generated TypeDoc HTML under
`docs/api/`. It is written for ChatGPT Projects, retrieval systems, and coding
agents that work better with small source files than one large HTML site.

## Ingestion Order

Use this order when adding these files to a ChatGPT Project:

1. `00-package-boundary.md`
2. `01-core-quick-start.md`
3. `02-writer-api.md`
4. `03-reader-api.md`
5. `04-blocks-and-inserts.md`
6. `05-terrain-3d-and-binary.md`
7. `06-renderer-and-osnap.md`
8. `07-utilities-and-types.md`
9. `08-limits-and-agent-rules.md`

## Import Boundaries

Root package import:

```ts
import { DXFReader, DXFWriter, DXFLayer } from "@jakkelab-aec/rw-dxf-engine-ts";
```

Renderer import:

```ts
import { DXFImportedObject3D } from "@jakkelab-aec/rw-dxf-engine-ts/renderer";
```

Do not import renderer APIs from the root package. The renderer subpath is
optional and expects the consuming project to provide `three`.

## File Map

- `00-package-boundary.md`
  - Package goals, dependency policy, import paths, and what the library does
    not do.
- `01-core-quick-start.md`
  - Minimal write, read, validate, terrain extraction, and renderer examples.
- `02-writer-api.md`
  - `DXFWriter`, layers, styles, writer entities, blocks, 3D writers, and
    serialization behavior.
- `03-reader-api.md`
  - `DXFReader.parse`, `DXFReader.validate`, raw group preservation,
    validation diagnostics, summaries, and unknown records.
- `04-blocks-and-inserts.md`
  - Block writing, block summaries, `INSERT` raw inspection, insertion points,
    and renderer block expansion.
- `05-terrain-3d-and-binary.md`
  - Terrain mesh extraction, `3DFACE`, `MESH`, legacy mesh `POLYLINE`,
    opaque `3DSOLID`, ACDSDATA, and binary hex helpers.
- `06-renderer-and-osnap.md`
  - `DXFImportedObject3D`, `buildDXFSceneEntities`, scene entities, text
    geometry, colors, OSNAP candidates, and snap queries.
- `07-utilities-and-types.md`
  - Structural point types, `DXFDrawUtils`, `UnicodeConverter`, and common
    public interfaces.
- `08-limits-and-agent-rules.md`
  - Supported subset, known limitations, extension rules, verification, and
    documentation maintenance guidance.

## How To Use This Set

For an implementation answer, prefer these Markdown files first, then fall back
to `docs/api.json` or `dist/**/*.d.ts` for exact signatures.

For changing library behavior, this folder is not enough. Also read:

- `AGENTS.md`
- `.agents/API_CONTRACT.md`
- `.agents/DXF_IMPLEMENTATION_ROADMAP.md`
- `.agents/DXF_FILE_FORMAT_VALIDATION_PLAN.md` when parser validation changes
- `.agents/DXF_REFERENCE_GUIDE.md` before changing DXF group-code behavior

