# rw-dxf-engine-ts

Near-zero-dependency TypeScript primitives for writing DXF strings and reading
DXF group/section data.

The library is intended to be small enough to embed in browser, desktop, and
server-side projects without pulling in runtime package dependencies. Tooling
such as TypeScript and TypeDoc is kept in `devDependencies`.

## Install

For GitHub Packages, add the scope registry mapping to the consuming project's
`.npmrc`:

```text
@jakkelab-aec:registry=https://npm.pkg.github.com
```

```bash
npm install @jakkelab-aec/rw-dxf-engine-ts
```

For local development before publishing:

```powershell
cmd /c npm install E:\DEV\Projects\RWApps\rw-dxf-engine-ts
```

## Current Scope

- write common DXF entities to a string
- write registered blocks with `BLOCKS` and `INSERT`, plus `BLOCK_RECORD`
  when exporting a modern DXF version
- parse DXF text into raw groups, named sections, and read summaries
- read BLOCK definitions and effective INSERT instances with block-local to
  drawing-coordinate transforms
- extract terrain-ready meshes from `3DFACE`, `MESH`, and legacy mesh
  `POLYLINE` entities
- preserve unknown/raw groups for raw round-trip workflows
- opt into a Three.js renderer subpath that builds an `Object3D` plus OSNAP
  data from parsed DXF content
- keep geometry input as simple structural `{ x, y, z }` objects
- avoid direct filesystem, DOM, Blob, or download behavior in the core package

Planned extension areas include richer read/write entity coverage,
schema-driven validation, and broader 3D mesh writing support.

## Usage

```ts
import {
	DXFBlock,
	DXFBlockInsert,
	DXFCircle,
	DXFLayer,
	DXFLine,
	DXFLwPolyline,
	DXFMText,
	DXFReader,
	DXFWriter,
	transformDXFBlockPoint,
} from "@jakkelab-aec/rw-dxf-engine-ts";

const layer = new DXFLayer("GEOMETRY", 3);
const writer = new DXFWriter();

writer.addComponent(
	new DXFLine(
		{ x: 0, y: 0, z: 0 },
		{ x: 100, y: 0, z: 0 },
		layer,
	),
);
writer.addComponent(new DXFCircle(50, 50, 0, 25, layer));
writer.addComponent(new DXFMText("Room note\\PSecond line", { x: 10, y: 60, z: 0 }, 2.5, layer, { width: 80 }));
writer.addComponent(
	new DXFLwPolyline(
		[
			{ x: 0, y: 0 },
			{ x: 100, y: 0, bulge: 0.25 },
			{ x: 100, y: 50 },
		],
		layer,
		{ closed: true },
	),
);

const dxf = writer.serialize("KOR");
const parsed = DXFReader.parse(dxf);
const validation = DXFReader.validate(dxf);
const rawRoundTrip = DXFReader.stringify(parsed);
const terrainMesh = DXFReader.extractTerrainMesh(parsed, { triangulate: true });
```

Blocks can be registered before adding `INSERT` entities:

```ts
const block = new DXFBlock("DOOR_BLOCK");
block.addEntity(new DXFLine({ x: 0, y: 0, z: 0 }, { x: 90, y: 0, z: 0 }, layer));

writer.registerBlock(block);
writer.addComponent(new DXFBlockInsert("DOOR_BLOCK", { x: 250, y: 100, z: 0 }));
```

When blocks are registered, the writer emits a `BLOCKS` section and keeps
block-only drawings on `AC1009` by default for broad AutoCAD/Rhino
compatibility. `BLOCK_RECORD` table entries are emitted when the resolved
`acadVersion` is not `AC1009`, such as `new DXFWriter({ acadVersion:
"AC1015" })`.

Generated files include the default table records expected by common CAD
loaders, including `VPORT`, `LTYPE`, `LAYER`, `STYLE`, `VIEW`, `UCS`, `APPID`,
and `DIMSTYLE`. For modern DXF versions (`AC1015+`), those tables and records
include generated handles, owner links, and subclass markers.

The package returns DXF text. Write that string with the file API provided by
your runtime.

## Block Model Reading

Use `DXFReader.getBlockModel()` when a host app needs to list block
definitions, find all resolved instances of a selected definition, or map a
point picked in block-local coordinates into drawing coordinates.

```ts
const blockModel = DXFReader.getBlockModel(dxfText, { maxBlockDepth: 4 });
const definition = blockModel.definitions.find((item) => item.name === "FOOTING_GRID");

if (definition) {
	const instances = blockModel.instances.filter((item) => item.blockName === definition.name);

	for (const instance of instances) {
		const drawingPoint = transformDXFBlockPoint(definition.basePoint, instance.transform);
		console.log(instance.blockName, drawingPoint);
	}
}
```

`definitions` preserves raw child entity records from the `BLOCKS` section and
reports `basePoint`, `flags`, `layer`, `entityCount`, and `entityTypes`.
`instances` contains resolved model-space and nested `INSERT` records. Each
instance has `insertionPoint`, `scale`, `rotation`, `depth`, `path`, raw groups,
and a `transform` that maps block-local points to drawing coordinates.
`unresolvedInstances` contains `INSERT` records whose referenced definition was
not found.

## Terrain Mesh Extraction

Use `DXFReader.extractTerrainMesh()` when a host app needs terrain-like faces
without traversing raw DXF groups itself.

```ts
const terrain = DXFReader.extractTerrainMesh(dxfText);

for (const face of terrain.faces) {
	const points = face.indices.map((index) => terrain.vertices[index]);
	console.log(points);
}
```

The extractor decodes `3DFACE` triangles/quads, modern `MESH` face lists, and
legacy `POLYLINE` polygon/polyface meshes. Quads are preserved by default; pass
`{ triangulate: true }` to emit triangles only. Malformed individual faces are
reported in `terrain.warnings` instead of throwing the whole parse.

`3DSOLID` payloads remain opaque. They are counted and reported through
`stats.unsupportedEntityTypes` plus a stable warning so importing apps can show
actionable messages. `DXFReader.getEntityInventory()` returns entity counts,
mesh-bearing counts, ignored drawing entity counts, and unsupported entity
types before extraction.

## 3DSOLID and ASM/ACIS Payloads

`3DSOLID` is an `ENTITIES` section entity. In many CAD exports, the actual
B-Rep modeler geometry is stored outside the entity in an `ACDSDATA` section as
an `ACDSRECORD` named `ASM_Data`, linked back to the 3DSOLID handle and stored
as group code `310` hex chunks.

This package treats `3DSOLID` as opaque modeler geometry for preservation and
writing. It does not generate ACIS/ASM B-Rep geometry from arbitrary mesh,
polyline, or extrusion inputs. Use `DXF3DSolid` when you already have a valid
ASM/ACIS payload or when you need lossless read/write preservation of existing
3DSOLID entities.

```ts
import {
	bytesToDxfHexChunks,
	DXF3DSolid,
	DXFLayer,
	DXFWriter,
} from "@jakkelab-aec/rw-dxf-engine-ts";

const layer = new DXFLayer("SOLID", 7);
const asmBytes = new Uint8Array([/* existing ASM/ACIS payload bytes */]);

const writer = new DXFWriter({ acadVersion: "AC1027" });

writer.addComponent(
	new DXF3DSolid({
		handle: "60",
		layer,
		modelerGeometryVersion: 1,
		asmData: {
			ownerHandle: "60",
			name: "ASM_Data",
			hexChunks: bytesToDxfHexChunks(asmBytes),
		},
	}),
);

const dxf = writer.serialize("KOR");
```

Reader summaries include `3DSOLID` counts and linked ASM payload byte/chunk
metadata when `ACDSDATA` is present. Missing linked `ASM_Data` records and
declared byte-size mismatches are warnings, not fatal validation errors.

## Three.js Renderer

The core root import stays dependency-free for parser/writer users. Three.js
projects can opt into the renderer subpath:

```bash
npm install three
```

```ts
import * as THREE from "three";
import {
	DXFImportedObject3D,
	buildDXFBlockDefinitionSceneEntities,
} from "@jakkelab-aec/rw-dxf-engine-ts/renderer";

const scene = new THREE.Scene();
const dxfObject = DXFImportedObject3D.fromDXFText(dxfText);

scene.add(dxfObject);

const snap = dxfObject.findOsnap({ x: 0, y: 0, z: 0 }, 5);
```

`DXFImportedObject3D` extends `THREE.Object3D`. Supported parsed entities are
added as selectable children with `userData.entityId` and `userData.entity`.
The renderer currently previews `LINE`, `CIRCLE`, `ARC`, `TEXT`, `MTEXT`,
`POLYLINE`, `LWPOLYLINE`, `SPLINE`, `INSERT`, `HATCH`, `3DFACE`, and `POINT`
from the reader's raw group data. OSNAP exposes endpoint, midpoint, center,
quadrant, insertion, vertex, nearest, perpendicular, and local intersection
queries.

`TEXT` and `MTEXT` are generated as `THREE.Mesh` objects backed by
Three.js `TextGeometry`. The renderer includes a default typeface JSON asset at
`@jakkelab-aec/rw-dxf-engine-ts/renderer/fonts/font_default.json`, and also
exports `DEFAULT_DXF_TEXT_FONT_DATA` and `getDXFTextFont()` for consumers that
need direct access to the packaged font data.

Use `buildDXFBlockDefinitionSceneEntities(dxfText, blockName)` to preview one
block definition in its own block-local coordinates, for example inside a
custom placement modal. Returned scene entities include optional
`sourceBlockName` and `sourceBlockBasePoint` metadata.

## Validation

Use `DXFReader.validate()` when you need a non-throwing read check with line
numbers and readable failure reasons.

```ts
const result = DXFReader.validate(dxfText);

if (!result.ok) {
	for (const issue of result.issues) {
		console.log(issue.line, issue.content, issue.reason);
	}
}
```

Successful validation also returns section, table, block, object, entity, and
unknown-record summaries that can be used by tools or coding agents.

## Commands

Use `cmd /c` from PowerShell if local script execution policy blocks npm shims.

```powershell
cmd /c npm install
cmd /c npm run build
cmd /c npm test
cmd /c npm run docs
cmd /c npm run verify
cmd /c npm run release:dry
cmd /c npm run release:github
cmd /c npm run release:github:minor
cmd /c npm run release:github:major
cmd /c npm run dev:tester
cmd /c npm run typecheck:tester
cmd /c npm run build:tester
```

`npm run dev:tester` starts a Vite + React DXF tester page. It is intentionally
kept outside the library build and package output.

Release shortcuts:

- `npm run verify`: library build, smoke test, and TypeDoc generation.
- `npm run verify:full`: `verify` plus tester typecheck and tester build.
- `npm run release:dry`: verify and inspect the package tarball without
  publishing.
- `npm run login:github`: authenticate to GitHub Packages.
- `npm run release:github`: bump patch version, verify, and publish to GitHub
  Packages.
- `npm run release:github:minor`: bump minor version, verify, and publish.
- `npm run release:github:major`: bump major version, verify, and publish.

The tester includes a Three.js orthographic XY viewer. Parsed `LINE`, `CIRCLE`,
`ARC`, `TEXT`, `MTEXT`, `POLYLINE`, `LWPOLYLINE`, `SPLINE`, `INSERT`,
`3DFACE`, and `POINT` entities are drawn into the scene when enough group data
is available. Click an entity in the viewer or in the summary table to inspect
it.

Use **Save JSON** in the tester to export an analysis report for Codex. The JSON
contains source file metadata, validation issues, read summaries, drawable scene
entities, parsed raw groups, and the original DXF text.

## API Documentation

Generate TypeDoc output with:

```powershell
cmd /c npm run docs
```

Generated files are written to:

- `docs/api/` for HTML
- `docs/api.json` for machine-readable API data

AI-oriented Markdown API notes live in:

- `docs/api-md/`

This folder is split into smaller topic files so ChatGPT Projects and coding
agents can use it as source material without needing to ingest the generated
HTML site.

Agent-oriented API usage rules are maintained separately in
`.agents/API_CONTRACT.md`.
